import LOGO_INDOQURAN from "./images/logo_indoquran.png";
import MEKAH_ICON from "./images/mekah_icon.png";
import MADINAH_ICON from "./images/madinah_icon.png";
import BISMILLAH from "./images/bismillah.png";
import IMAGE_PLACEHOLDER from "./images/image_placeholder.jpg";
import IMAGE_IMSAK from "./images/imsak.jpg";
import IMAGE_SUBUH from "./images/subuh.jpg";
import IMAGE_DHUHA from "./images/dhuha.jpg";
import IMAGE_DZUHUR from "./images/dzuhur.jpg";
import IMAGE_ASHAR from "./images/ashar.jpg";
import IMAGE_MAGHRIB from "./images/maghrib.jpg";
import IMAGE_ISYA from "./images/isya.jpg";
import IMAGE_NIGHT_KABAH from "./images/night_kabah.jpg";
import IMAGE_PROFILE_INDOQURAN from "./images/profile_indoquran.jpg";
import IMAGE_BG_ROADTORAMADHAN from "./images/bg-roadtoramadhan.png";

export {
  LOGO_INDOQURAN,
  MEKAH_ICON,
  MADINAH_ICON,
  IMAGE_PLACEHOLDER,
  IMAGE_IMSAK,
  IMAGE_SUBUH,
  IMAGE_DHUHA,
  IMAGE_DZUHUR,
  IMAGE_ASHAR,
  IMAGE_MAGHRIB,
  IMAGE_ISYA,
  BISMILLAH,
  IMAGE_NIGHT_KABAH,
  IMAGE_PROFILE_INDOQURAN,
  IMAGE_BG_ROADTORAMADHAN,
};
