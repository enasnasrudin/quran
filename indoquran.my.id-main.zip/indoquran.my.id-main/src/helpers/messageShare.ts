const messageShare = (): string => {
  return `*Assalamualaikum Izin Share*`;
};

export default messageShare;
