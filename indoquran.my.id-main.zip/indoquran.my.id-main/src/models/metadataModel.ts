export interface MetadataModel {
  title?: string;
  metaDescription?: string;
  ogImageUrl?: string;
}
